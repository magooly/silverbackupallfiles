package com.projects.holding;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.projects.holding.DBManager.GoldT_DB;
import com.projects.holding.DBManager.SilverT_DB;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddListActivity extends AppCompatActivity {

    private static final String TAG = "TAG";
    private static final int REQUEST_WRITE_STORAGE = 113;

    private RadioButton rb_silver, rb_gold;
    private EditText et_no, et_wight, et_what, et_total;
    private String mode = "", no = "", weight = "", what = "", total = "", time = "", date = "";
    private Context mContext;
    private SilverT_DB silverT_db;
    private GoldT_DB goldT_db;
    private float prd_no, prd_weight, total_price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_list);

        // Enable back button in the action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Add New Item");
        }

        setupViews();
        checkPermissions();
    }

    private void setupViews() {
        mContext = this;
        silverT_db = new SilverT_DB(mContext);
        goldT_db = new GoldT_DB(mContext);

        rb_silver = findViewById(R.id.rb_silver);
        rb_gold = findViewById(R.id.rb_gold);
        et_no = findViewById(R.id.et_no);
        et_wight = findViewById(R.id.et_wight);
        et_what = findViewById(R.id.et_what);
        et_total = findViewById(R.id.et_total);
        Button btn_clear = findViewById(R.id.btn_clear);
        Button btn_add = findViewById(R.id.btn_add);

        rb_silver.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                mode = "S";
            }
        });

        rb_gold.setOnCheckedChangeListener((compoundButton, b) -> {
            if (b) {
                mode = "G";
            }
        });

        btn_clear.setOnClickListener(view -> cleartext());
        btn_add.setOnClickListener(view -> addData());

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkData(et_no.getText().toString(), et_wight.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {}
        };

        et_no.addTextChangedListener(textWatcher);
        et_wight.addTextChangedListener(textWatcher);
    }

    private void checkData(String no, String weight) {
        try {
            if (!no.isEmpty() && !weight.isEmpty()) {
                prd_no = Float.parseFloat(no);
                prd_weight = Float.parseFloat(weight);
                total_price = prd_no * prd_weight;
                et_total.setText(new DecimalFormat("#,##0").format(total_price));
            } else {
                et_total.setText("");
            }
        } catch (NumberFormatException e) {
            et_total.setText("");
        }
    }

    private void cleartext() {
        rb_silver.setChecked(false);
        rb_gold.setChecked(false);
        et_no.setText("");
        et_wight.setText("");
        et_what.setText("");
        et_total.setText("");
    }

    private void addData() {
        no = et_no.getText().toString();
        weight = et_wight.getText().toString();
        what = et_what.getText().toString();
        total = et_total.getText().toString();

        if (mode.isEmpty()) {
            showToast(R.string.please_select_type);
        } else if (no.isEmpty()) {
            showToast(R.string.please_enter_number);
        } else if (weight.isEmpty()) {
            showToast(R.string.please_enter_weight);
        } else if (what.isEmpty()) {
            showToast(R.string.please_enter_what);
        } else if (total.isEmpty()) {
            showToast(R.string.please_enter_total);
        } else {
            addDataInDB();
        }
    }

    private void addDataInDB() {
        date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("HH:mm:ss a", Locale.getDefault());
        time = mdformat.format(calendar.getTime());

        if ("G".equals(mode)) {
            boolean insert = goldT_db.insertData(no, weight, what, total, date, time);
            if (insert) {
                showToast(R.string.gold_data_add_sucess);
                finish();
            } else {
                showToast(R.string.gold_data_add_failed);
            }
        } else if ("S".equals(mode)) {
            boolean insert = silverT_db.insertData(no, weight, what, total, date, time);
            if (insert) {
                showToast(R.string.silver_data_add_sucess);
                finish();
            } else {
                showToast(R.string.silver_data_add_failed);
            }
        }
    }

    private void showToast(int resId) {
        Toast.makeText(mContext, getString(resId), Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_WRITE_STORAGE);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WRITE_STORAGE) {
            if (grantResults.length == 0 || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this,
                        "Storage permission is required to save data.",
                        Toast.LENGTH_LONG).show();
            }
        }
    }
}