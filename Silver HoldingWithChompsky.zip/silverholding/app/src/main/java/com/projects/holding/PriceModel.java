package com.projects.holding;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public  class PriceModel {


    @Expose
    @SerializedName("rates")
    private RatesEntity rates;
    @Expose
    @SerializedName("base")
    private String base;
    @Expose
    @SerializedName("timestamp")
    private int timestamp;
    @Expose
    @SerializedName("success")
    private boolean success;
    @Expose
    @SerializedName("error")
    private ErrorEntity error;

    public ErrorEntity getError() {
        return error;
    }

    public void setError(ErrorEntity error) {
        this.error = error;
    }

    public RatesEntity getRates() {
        return rates;
    }

    public void setRates(RatesEntity rates) {
        this.rates = rates;
    }

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public int getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(int timestamp) {
        this.timestamp = timestamp;
    }

    public boolean getSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public static class ErrorEntity {
        @Expose
        @SerializedName("statusCode")
        private int statusCode;
        @Expose
        @SerializedName("message")
        private String message;

        public int getStatusCode() {
            return statusCode;
        }

        public void setStatusCode(int statusCode) {
            this.statusCode = statusCode;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    public static class RatesEntity {
        @Expose
        @SerializedName("AUDXAG")
        private double audxag;
        @Expose
        @SerializedName("AUDXAU")
        private double audxau;
        @Expose
        @SerializedName("XAG")
        private double xag;
        @Expose
        @SerializedName("XAU")
        private double xau;

        public double getAudxag() {
            return audxag;
        }

        public void setAudxag(double audxag) {
            this.audxag = audxag;
        }

        public double getAudxau() {
            return audxau;
        }

        public void setAudxau(double audxau) {
            this.audxau = audxau;
        }

        public double getXag() {
            return xag;
        }

        public void setXag(double xag) {
            this.xag = xag;
        }

        public double getXau() {
            return xau;
        }

        public void setXau(double xau) {
            this.xau = xau;
        }
    }
}
