package com.projects.holding;import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import androidx.appcompat.app.AlertDialog;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.projects.holding.Adapter.GoldTListAdapter;
import com.projects.holding.Adapter.SilverTListAdapter;
import com.projects.holding.DBManager.GoldT_DB;
import com.projects.holding.DBManager.SilverT_DB;
import com.projects.holding.DBManager.SilverT_DBModel;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Locale;
import android.text.InputType;
import java.io.File;
import java.io.ByteArrayOutputStream;

public class ResListActivity extends AppCompatActivity {
    private static final String TAG = "TAG";
    // THIS IS THE CONSTANT ADDED FOR PERMISSIONS
    private static final int REQUEST_WRITE_STORAGE = 112;

    RecyclerView rcview_silver, rcview_gold;
    TextView tv_slv_ttl_amount, tv_gld_ttl_amount;
    Button btn_silver_update, btn_gold_update;
    Context mContext;
    SilverT_DB silverT_db;
    GoldT_DB goldT_db;
    List<SilverT_DBModel> alGoldList;
    List<SilverT_DBModel> alSilverList;
    GoldTListAdapter goldTListAdapter;
    SilverTListAdapter silverTListAdapter;
    String mode = "", p_id = "", p_no = "", p_weight = "", p_what = "", p_total = "", time = "", date = "", totalSlvAmt = "", totalGldAmt = "";
    EditText et_no, et_wight, et_what, et_total;
    Button btn_cancel, btn_add;
    private FloatingActionButton bt_add;
    float prd_price;
    float prd_no, prd_weight, total_price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_res_list);
        
        // Set up the Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        
        // Enable the back button in the toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(false); // Hide default title
        }
        
        // Set click listener for the back button
        toolbar.setNavigationOnClickListener(v -> onBackPressed());
        
        setUpViews();
        // THIS CALL IS ADDED TO CHECK PERMISSIONS ON STARTUP
        checkPermissions();
    }

    // NEW METHOD ADDED
    private void checkPermissions() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_STORAGE);
            }
        }
    }

    // NEW METHOD ADDED
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WRITE_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted. The user can now add items without crashing.
            } else {
                Toast.makeText(this, "Storage permission is required to save items.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void setUpViews() {
        mContext = ResListActivity.this;
        silverT_db = new SilverT_DB(mContext);
        goldT_db = new GoldT_DB(mContext);
        getSupportActionBar().setTitle("Silver $ Gold Holding");
        tv_slv_ttl_amount = findViewById(R.id.tv_slv_ttl_amount);
        tv_gld_ttl_amount = findViewById(R.id.tv_gld_ttl_amount);
        rcview_silver = findViewById(R.id.rcview_silver);
        rcview_gold = findViewById(R.id.rcview_gold);
        bt_add = findViewById(R.id.bt_add);
        btn_silver_update = findViewById(R.id.btn_silver_update);
        btn_gold_update = findViewById(R.id.btn_gold_update);

        getGoldData();
        getSilverData();

        bt_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mContext, AddListActivity.class));
            }
        });
    }

    private void getSilverData() {
        totalSlvAmt = "";
        total_price = 0;
        prd_price = 0;

        alSilverList = silverT_db.getSilverList();
        if (alSilverList.size() > 0) {
            silverTListAdapter = new SilverTListAdapter(mContext, alSilverList, ResListActivity.this);
            rcview_silver.setLayoutManager(new LinearLayoutManager(mContext));
            rcview_silver.setAdapter(silverTListAdapter);

            for (int i = 0; i < alSilverList.size(); i++) {
                String ttl = alSilverList.get(i).getX_S_TOTAL();
                Log.d(TAG, "getSilverData: ttl " + ttl);
                try {
                    prd_price = Float.parseFloat(ttl);
                    total_price = total_price + prd_price;
                } catch (NumberFormatException e) {
                    Log.e(TAG, "Could not parse silver total value: " + ttl);
                }
            }
            totalSlvAmt = String.valueOf(total_price);
            tv_slv_ttl_amount.setText(totalSlvAmt);
        }
    }

    private void getGoldData() {
        totalGldAmt = "";
        total_price = 0;
        prd_price = 0;

        alGoldList = goldT_db.getGoldList();
        if (alGoldList.size() > 0) {
            goldTListAdapter = new GoldTListAdapter(mContext, alGoldList, ResListActivity.this);
            rcview_gold.setLayoutManager(new LinearLayoutManager(mContext));
            rcview_gold.setAdapter(goldTListAdapter);

            for (int i = 0; i < alGoldList.size(); i++) {
                String ttl = alGoldList.get(i).getX_S_TOTAL();
                try {
                    prd_price = Float.parseFloat(ttl);
                    total_price = total_price + prd_price;
                } catch (NumberFormatException e) {
                    Log.e(TAG, "Could not parse gold total value: " + ttl);
                }
            }
            totalGldAmt = String.valueOf(total_price);
            tv_gld_ttl_amount.setText(totalGldAmt);
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (alGoldList != null) {
            alGoldList.clear();
        }
        getGoldData();
        if (alSilverList != null) {
            alSilverList.clear();
        }
        getSilverData();
    }

    public void displayPopUp(final String md, final String id, String no, String weight, String what, String total) {
        final androidx.appcompat.app.AlertDialog.Builder dialogBuilder = new androidx.appcompat.app.AlertDialog.Builder(mContext, R.style.MyDialogTheme);
        LayoutInflater inflater = this.getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.update_item_popup, null);
        dialogBuilder.setView(dialogView);

        btn_add = dialogView.findViewById(R.id.btn_add);
        btn_cancel = dialogView.findViewById(R.id.btn_cancel);
        et_no = dialogView.findViewById(R.id.et_no);
        et_wight = dialogView.findViewById(R.id.et_wight);
        et_what = dialogView.findViewById(R.id.et_what);
        et_total = dialogView.findViewById(R.id.et_total);

        et_no.setText(no);
        et_wight.setText(weight);
        et_what.setText(what);
        et_total.setText(total);

        final androidx.appcompat.app.AlertDialog b = dialogBuilder.create();

        if ("G".equals(md)) {
            b.setTitle("Gold");
        } else if ("S".equals(md)) {
            b.setTitle("Silver");
        }

        b.show();
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                b.dismiss();
            }
        });
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mode = md;
                p_id = id;
                p_no = et_no.getText().toString();
                p_weight = et_wight.getText().toString();
                p_what = et_what.getText().toString();
                p_total = et_total.getText().toString();
                validateData(mode, p_id, p_no, p_weight, p_what, p_total, b);
            }
        });

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                checkData(et_no.getText().toString(), et_wight.getText().toString());
            }
            @Override
            public void afterTextChanged(Editable editable) {}
        };

        et_no.addTextChangedListener(textWatcher);
        et_wight.addTextChangedListener(textWatcher);
    }

    private void checkData(String no, String weight) {
        prd_no = 0;
        prd_weight = 0;
        total_price = 0;
        if (!no.isEmpty() && !weight.isEmpty()) {
            try {
                prd_no = Float.parseFloat(no);
                prd_weight = Float.parseFloat(weight);
                total_price = prd_no * prd_weight;
                et_total.setText(new DecimalFormat("#,##0").format(total_price));
            } catch (NumberFormatException e) {
                et_total.setText("");
            }
        } else {
            et_total.setText("");
        }
    }

    private void validateData(String mode, String p_id, String p_no, String p_weight, String p_what, String p_total, AlertDialog b) {
        if (p_no.isEmpty()) {
            Toast.makeText(mContext, "" + getString(R.string.please_enter_number), Toast.LENGTH_SHORT).show();
        } else if (p_weight.isEmpty()) {
            Toast.makeText(mContext, "" + getString(R.string.please_enter_weight), Toast.LENGTH_SHORT).show();
        } else if (p_what.isEmpty()) {
            Toast.makeText(mContext, "" + getString(R.string.please_enter_what), Toast.LENGTH_SHORT).show();
        } else if (p_total.isEmpty()) {
            Toast.makeText(mContext, "" + getString(R.string.please_enter_total), Toast.LENGTH_SHORT).show();
        } else {
            date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat mdformat = new SimpleDateFormat("HH:mm:ss a");
            time = mdformat.format(calendar.getTime());

            if ("G".equals(mode)) {
                boolean update = goldT_db.updateData(p_id, p_no, p_weight, p_what, p_total, date, time);
                if (update) {
                    Toast.makeText(mContext, "" + getString(R.string.gold_data_update_sucess), Toast.LENGTH_SHORT).show();
                    b.dismiss();
                } else {
                    Toast.makeText(mContext, "" + getString(R.string.gold_data_update_failed), Toast.LENGTH_SHORT).show();
                }
            } else if ("S".equals(mode)) {
                boolean update = silverT_db.updateData(p_id, p_no, p_weight, p_what, p_total, date, time);
                if (update) {
                    Toast.makeText(mContext, "" + getString(R.string.silver_data_update_sucess), Toast.LENGTH_SHORT).show();
                    b.dismiss();
                } else {
                    Toast.makeText(mContext, "" + getString(R.string.silver_data_update_failed), Toast.LENGTH_SHORT).show();
                }
            }
            onResume();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_about) {
            showAboutDialog();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showAboutDialog() {
        try {
            String aboutText = readAboutFile();
            
            // Create a scrollable TextView to display the text
            ScrollView scrollView = new ScrollView(this);
            TextView textView = new TextView(this);
            textView.setText(aboutText);
            textView.setPadding(32, 32, 32, 32);
            textView.setTextSize(16);
            scrollView.addView(textView);

            // Create and show the dialog
            AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("About")
                    .setView(scrollView)
                    .setPositiveButton("Close", (d, which) -> d.dismiss())
                    .setNeutralButton("Edit", (d, which) -> showEditAboutDialog(aboutText))
                    .create();
            dialog.show();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading about information", Toast.LENGTH_SHORT).show();
        }
    }
    
    private String readAboutFile() throws IOException {
        // First try to read from internal storage
        try {
            return readInternalAboutFile();
        } catch (IOException e) {
            // If internal storage read fails, try external storage
            String state = Environment.getExternalStorageState();
            if (Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
                try {
                    File aboutDir = new File(Environment.getExternalStorageDirectory(), "SilverHolding");
                    File aboutFile = new File(aboutDir, "about.txt");
                    
                    if (aboutFile.exists()) {
                        FileInputStream fis = new FileInputStream(aboutFile);
                        String content = readStream(fis);
                        fis.close();
                        return content;
                    }
                } catch (IOException ex) {
                    // Continue to assets if external storage read fails
                }
            }
            
            // If both internal and external storage fail, read from assets
            InputStream is = getAssets().open("about.txt");
            String defaultContent = readStream(is);
            is.close();
            
            // Save the default content to internal storage for next time
            saveToInternalStorage(defaultContent);
            
            return defaultContent;
        }
    }
    
    private String readInternalAboutFile() throws IOException {
        // Try to read from internal storage
        File internalFile = new File(getFilesDir(), "about.txt");
        if (internalFile.exists()) {
            FileInputStream fis = openFileInput("about.txt");
            String content = readStream(fis);
            fis.close();
            return content;
        }
        
        // If not found in internal storage, throw FileNotFoundException
        // to allow readAboutFile to try other sources
        throw new FileNotFoundException("About file not found in internal storage");
    }
    
    private String readStream(InputStream inputStream) throws IOException {
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        int length;
        while ((length = inputStream.read(buffer)) != -1) {
            result.write(buffer, 0, length);
        }
        return result.toString(StandardCharsets.UTF_8.name());
    }
    
    private void showEditAboutDialog(String currentText) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit About Text");
        
        // Set up the input
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        input.setLines(8);
        input.setMaxLines(10);
        input.setScrollBarStyle(View.SCROLLBARS_INSIDE_INSET);
        input.setText(currentText);
        input.setSelection(input.getText().length());
        
        builder.setView(input);
        
        // Set up the buttons
        builder.setPositiveButton("Save", (dialog, which) -> {
            String newText = input.getText().toString();
            saveAboutText(newText);
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        
        builder.show();
    }
    
    private void saveAboutText(String text) {
        // Always save to internal storage first (this works on all Android versions)
        try {
            saveToInternalStorage(text);
            
            // For Android 9 (API 28) and below, also save to external storage
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                String state = Environment.getExternalStorageState();
                if (Environment.MEDIA_MOUNTED.equals(state)) {
                    try {
                        File aboutDir = new File(Environment.getExternalStorageDirectory(), "SilverHolding");
                        if (!aboutDir.exists()) {
                            aboutDir.mkdirs();
                        }
                        File aboutFile = new File(aboutDir, "about.txt");
                        FileOutputStream fos = new FileOutputStream(aboutFile);
                        fos.write(text.getBytes(StandardCharsets.UTF_8));
                        fos.close();
                        Toast.makeText(this, "About text saved to both internal and external storage", Toast.LENGTH_SHORT).show();
                    } catch (IOException e) {
                        e.printStackTrace();
                        // Ignore external storage errors on older Android versions
                    }
                }
            } else {
                // For Android 10+, we only use internal storage
                Toast.makeText(this, "About text saved", Toast.LENGTH_SHORT).show();
            }
            
            showAboutDialog();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving about text: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    
    private void saveToInternalStorage(String text) throws IOException {
        FileOutputStream fos = openFileOutput("about.txt", Context.MODE_PRIVATE);
        fos.write(text.getBytes());
        fos.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.navigation, menu);
        return true;
    }
}
