package com.projects.holding;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.projects.holding.DBManager.GoldT_DB;
import com.projects.holding.DBManager.SilverDB;
import com.projects.holding.DBManager.SilverDBModel;
import com.projects.holding.DBManager.SilverT_DB;
import com.projects.holding.DBManager.SilverT_DBModel;
import com.projects.holding.Retrofit.ApiHelperClass;
import com.projects.holding.Retrofit.ApiWebservices;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "TAG";
    private static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 101;
    Context mContext;
    EditText et_slv_slv_price_amount, et_slv_gld_amount;
    TextView tv_slv_ttl_amount, tv_hld_slv_price_amount, tv_hld_gld_amount, tv_hld_ttl_amount, tvDate;
    Button btn_holding_update, btn_silver_update;
    String slv_gld_price, slv_slv_price, time, date;
    SilverDB silverDB;
    SilverT_DB silverT_db;
    GoldT_DB goldT_db;
    float prd_price;
    float silver_total = 0, gold_total = 0, d_gold_amt, d_silver_amt, lv_gold_amt, lv_slv_amt;
    List<SilverT_DBModel> alGoldList;
    List<SilverT_DBModel> alSilverList;
    List<SilverDBModel> alSilver;
    private int request_code;
    private PriceModel priceModelRes;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    private String pendingDataToWrite = null;
    private boolean shouldNavigateToResList = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        preferences = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE);
        editor = preferences.edit();
        setupViews();
        getAPIdata();
        getSilverData();
        getGoldData();

        // REQUEST PERMISSIONS ON STARTUP
        checkAndRequestPermissions();
    }


    private void getLiveData() {
        if (CustomNetwork.isNetworkAvailable(mContext)) {
            ApiWebservices apiWebservices = ApiHelperClass.getClient().create(ApiWebservices.class);
            Call<PriceModel> call = apiWebservices.getPriceRes("885450b505ea1cde039b28b14e1935c7", "AUD", "XAU,XAG");
            call.enqueue(new Callback<PriceModel>() {
                @Override
                public void onResponse(@NonNull Call<PriceModel> call, @NonNull Response<PriceModel> response) {
                    if (response.isSuccessful() && response.body() != null && response.body().getSuccess()) {
                        priceModelRes = response.body();
                        lv_gold_amt = Float.parseFloat(String.valueOf(priceModelRes.getRates().getAudxau()));
                        lv_slv_amt = Float.parseFloat(String.valueOf(priceModelRes.getRates().getAudxag()));
                        slv_gld_price = String.valueOf(lv_gold_amt);
                        slv_slv_price = String.valueOf(lv_slv_amt);
                        updateUI();
                        insertdatainDB();
                    }
                }
                @Override
                public void onFailure(@NonNull Call<PriceModel> call, @NonNull Throwable t) {
                    Toast.makeText(mContext, "Failed to fetch live data.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void setupViews() {
        mContext = MainActivity.this;
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowHomeEnabled(true);
            actionBar.setDisplayUseLogoEnabled(true);
        }

        // ... (Find views by ID)
        et_slv_slv_price_amount = findViewById(R.id.et_slv_slv_price_amount);
        et_slv_gld_amount = findViewById(R.id.et_slv_gld_amount);
        tv_hld_slv_price_amount = findViewById(R.id.tv_hld_slv_price_amount);
        tv_hld_gld_amount = findViewById(R.id.tv_hld_gld_amount);
        tv_hld_ttl_amount = findViewById(R.id.tv_hld_ttl_amount);
        btn_holding_update = findViewById(R.id.btn_holding_update);
        btn_silver_update = findViewById(R.id.btn_silver_update);
        tvDate = findViewById(R.id.tvDate);
        btn_holding_update.setOnClickListener(this);
        btn_silver_update.setOnClickListener(this);

        silverDB = new SilverDB(mContext);
        silverT_db = new SilverT_DB(mContext);
        goldT_db = new GoldT_DB(mContext);
    }

    private void updateUI() {
        float current_silver_price = d_silver_amt > 0 ? d_silver_amt : lv_slv_amt;
        float current_gold_price = d_gold_amt > 0 ? d_gold_amt : lv_gold_amt;

        // Format prices with commas for thousands and no decimal places
        DecimalFormat priceFormat = new DecimalFormat("#,##0");
        
        // Format the input fields
        et_slv_slv_price_amount.setText(priceFormat.format(current_silver_price));
        et_slv_gld_amount.setText(priceFormat.format(current_gold_price));

        // Calculate and format the holding values
        float silverHolding = silver_total * current_silver_price;
        float goldHolding = gold_total * current_gold_price;
        float totalHolding = silverHolding + goldHolding;
        
        // Format the holding amounts with commas and 2 decimal places
        tv_hld_slv_price_amount.setText(priceFormat.format(silverHolding));
        tv_hld_gld_amount.setText(priceFormat.format(goldHolding));
        tv_hld_ttl_amount.setText(priceFormat.format(totalHolding));

        // Only generate data if we have live prices
        if (lv_slv_amt > 0) {
            generateData(priceFormat.format(totalHolding));
        }
    }

    private void getSilverData() {
        silver_total = 0;
        alSilverList = silverT_db.getSilverList();
        if (alSilverList != null && !alSilverList.isEmpty()) {
            for (SilverT_DBModel item : alSilverList) {
                try {
                    silver_total += Float.parseFloat(item.getX_S_TOTAL());
                } catch (NumberFormatException e) {
                    Log.e(TAG, "Error parsing silver total", e);
                }
            }
        }
        updateUI();
    }

    private void getGoldData() {
        gold_total = 0;
        alGoldList = goldT_db.getGoldList();
        if (alGoldList != null && !alGoldList.isEmpty()) {
            for (SilverT_DBModel item : alGoldList) {
                try {
                    gold_total += Float.parseFloat(item.getX_S_TOTAL());
                } catch (NumberFormatException e) {
                    Log.e(TAG, "Error parsing gold total", e);
                }
            }
        }
        updateUI();
    }

    private void getAPIdata() {
        d_gold_amt = 0;
        d_silver_amt = 0;
        alSilver = silverDB.getSilverData(date);
        if (alSilver != null && !alSilver.isEmpty()) {
            Log.d(TAG, "Offline data fetched");
            try {
                d_gold_amt = Float.parseFloat(alSilver.get(0).getGold());
                d_silver_amt = Float.parseFloat(alSilver.get(0).getSilver());
            } catch (NumberFormatException e) {
                Log.e(TAG, "Error parsing offline data", e);
            }
            tvDate.setText(alSilver.get(0).getDate());
            updateUI();
        } else {
            Log.d(TAG, "Online data fetched");
            getLiveData();
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btn_silver_update) {
            getLiveData();
        } else if (id == R.id.btn_holding_update) {
            // DIRECTLY START THE ACTIVITY
            startActivity(new Intent(mContext, ResListActivity.class));
        }
    }


    private void insertdatainDB() {
        // ... (This method remains the same)
        date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat mdformat = new SimpleDateFormat("HH:mm:ss a", Locale.US);
        time = mdformat.format(calendar.getTime());
        tvDate.setText(time);
        if (slv_slv_price != null && !slv_slv_price.isEmpty()) {
            if (silverDB.getSilverData(date).isEmpty()) {
                silverDB.insertData("", slv_slv_price, slv_gld_price, date, time);
            } else {
                silverDB.updateData("1", slv_slv_price, slv_gld_price, date, time);
            }
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        // Refresh data when returning to the activity
        getAPIdata();
        getSilverData();
        getGoldData();
    }

    public void generateData(String total) {
        if (total == null || total.equals("0") || total.equals(".00")) {
            return;
        }
        pendingDataToWrite = date + "," + total;
        // Check permissions right before writing
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                // If permission is not granted, we don't proceed.
                // The user needs to trigger an action that asks for permission.
                return;
            }
        }
        executeFileWriting();
    }

    private void executeFileWriting() {
        if (pendingDataToWrite == null) return;
        String getPreferenceDate = preferences.getString("Date", "");
        if (getPreferenceDate.isEmpty() || !getPreferenceDate.equals(date)) {
            writeTextFile(pendingDataToWrite);
        }
        pendingDataToWrite = null;
    }

    @SuppressLint("NewApi")
    private void checkAndRequestPermissions() {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_ID_MULTIPLE_PERMISSIONS);
                return; // Wait for user response
            }
        }
        // If permissions are already granted or not needed (Android 11+), proceed.
        if (shouldNavigateToResList) {
            navigateToResListActivity();
        }
    }

    private void navigateToResListActivity() {
        shouldNavigateToResList = false; // Reset the flag
        startActivity(new Intent(mContext, ResListActivity.class));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_ID_MULTIPLE_PERMISSIONS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted
                if (shouldNavigateToResList) {
                    navigateToResListActivity();
                }
            } else {
                Toast.makeText(mContext, "Storage permission is required to add items.", Toast.LENGTH_LONG).show();
                shouldNavigateToResList = false; // Reset flag if permission is denied
            }
        }
    }

    private void writeTextFile(String sBody) {
        try {
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            File root = new File(dir, mContext.getString(R.string.app_name));
            if (!root.exists() && !root.mkdirs()) {
                Log.e(TAG, "Failed to create directory");
                return;
            }
            editor.putString("Date", date).apply();
            File gpxfile = new File(root, mContext.getString(R.string.app_name) + ".txt");
            FileWriter writer = new FileWriter(gpxfile, true);
            writer.append(sBody).append("\n");
            writer.flush();
            writer.close();
            Toast.makeText(mContext, "File data saved in Documents folder", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Log.e(TAG, "generateData: failed", e);
        }
    }
}


